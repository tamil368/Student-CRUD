using System.ComponentModel.DataAnnotations;

namespace crud.Models
{
    public class Students
    {
        [Key] //Primary Key

        // Id
        public int Id { get; set; }

        // Name
        [Required(ErrorMessage = "Name is Required")]
        public string Name { get; set; } = null!;

        // Email
        [Required(ErrorMessage = "Email is Required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = null!;

        // Phone 
        [Required(ErrorMessage = "Phone Number is Required")]
        [Phone(ErrorMessage = "Invalid Phone Number")]
        [DataType(DataType.PhoneNumber)]
        public string PhoneNumber { get; set; } = null!;

        // DateBirth
        [Required(ErrorMessage = "Date Of Birth is Required")]
        [DataType(DataType.Date)]
        public DateOnly DateOfBirth { get; set; }

        // Gender
        [Required(ErrorMessage ="Gender is Required")]
        public string Gender{get;set;}=null!;

        // Address
        [Required(ErrorMessage ="Address is Required")]
        public string Address{get;set;}=null!;

    }
}