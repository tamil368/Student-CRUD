document.addEventListener("DOMContentLoaded", function () {
    loadStudents();
});

function loadStudents() {
    fetch('/Students/GetStudents')
        .then(res => res.json())
        .then(students => {

            const table = document.getElementById("studentTable");
            table.innerHTML = "";

            students.forEach(s => {
                const row = `
                    <tr>
                        <td>${s.studentName}</td>
                        <td>${s.studentEmail}</td>
                        <td>${s.phoneNumber}</td>
                        <td>${formatDate(s.dateOfBirth)}</td>
                        <td>${s.gender}</td>
                        <td>${s.address}</td>
                    </tr>`;
                table.innerHTML += row;
            });
        });
}

function formatDate(date) {
    return new Date(date).toLocaleDateString();
}
