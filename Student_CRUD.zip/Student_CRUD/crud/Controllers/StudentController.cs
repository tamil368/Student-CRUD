using System.Reflection.Metadata.Ecma335;
using crud.Models;
using Microsoft.AspNetCore.Mvc;

public class StudentsController : Controller
{
    private readonly StudentDbContext db;

    public StudentsController(StudentDbContext Db_)
    {
        db = Db_;
    }

    // GET: All Records
    [HttpGet]
    public IActionResult Index()
    {
        var students = db.students.ToList();
        return View(students);
    }

    // GET: Create Page
    public IActionResult Create()
    {
        return View();
    }

    // POST: Save New Student
    [HttpPost]
    public IActionResult Create(Students students)
    {
        if (ModelState.IsValid)
        {
            db.Add(students);
            db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        return View(students);
    }

    // GET: Update Page
    [HttpGet]
    public IActionResult Update(int id)
    {
        var students = db.students.Find(id);

        if (students == null)
        {
            return NotFound();
        }

        return View(students);
    }

    // POST: Update Data
    [HttpPost]
    public IActionResult Update(Students students)
    {
        if (ModelState.IsValid)
        {
            db.Update(students);
            db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        return View(students);
    }

    // GET: Details
    [HttpGet]
    public IActionResult Details(int id)
    {
        var students = db.students.Find(id);
        if (students == null)
        {
            return NotFound();
        }
        return View(students);
    }

public IActionResult Delete(int id)
{
    var student = db.students.Find(id);

    if (student == null)
    {
        return NotFound();
    }

    return View(student);
}

    // DELETE: Record
    [HttpPost,ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        var students=db.students.Find(id);
        if (students == null)
        {
            return NotFound();
        }
        db.Remove(students);
        db.SaveChanges();

        return RedirectToAction(nameof(Index));
    }
}
